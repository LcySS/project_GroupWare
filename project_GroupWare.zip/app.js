var express = require('express');
var http = require('http');
var createError = require('http-errors');
var app = express();

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/views'));

app.use(express.static('public'));

var indexRouter = require('./routes/index');
app.use('/', indexRouter);

app.listen(3000,function(){
    console.log('express webserver start ! :: 3000');
})

module.exports = app;