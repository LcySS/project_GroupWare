var express = require('express');
var router = express.Router();
const mysql = require('mysql2');
var db = require('../db');

var main = require('./main');
var personaldb = require('./personaldb');
var inventorydb = require('./inventorydb');
var salarydb = require('./salarydb');

router.use('/', main);
router.use('/personal', personaldb);
router.use('/inventory', inventorydb);
router.use('/salary', salarydb);
/*
router.get('/', function(req, res){
    res.render('main');
});

router.get('/inventory', function(req, res){
    res.render('inventory');
});

router.get('/personal', function(req, res){
    res.render('personal')
});

router.get('/salary', function(req, res){
    res.render('salary');
});
*/
module.exports = router;