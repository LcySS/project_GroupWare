const express = require('express');
const router = express.Router();
const connection = require('../db');

/*router.get('/', function(req, res){
  res.render('inventory');
});
*/
router.get('/', function(req, res) {
  const query = req.query.query;
  
  const sql = `SELECT inventory_name, amount FROM inventory WHERE inventory_name LIKE '${query}'`;
  
  connection.query(sql, function(err, results, fields) {
    if (err){
      res.render('inventorySearch', {data: err});
      console.log(err);
    } 
    console.log(results);
    res.render('inventorySearch', {data:results});
  });
});

module.exports = router;
