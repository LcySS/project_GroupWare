const express = require('express');
const router = express.Router();
const connection = require('../db');
const { Op } = require('sequelize');
/*
router.get('/', function(req, res){
  res.render('salary');
});
*/
router.get('/', function(req, res) {
  const query = req.query.query;
  
  const sql = `SELECT salary, rank_name FROM salary WHERE rank_name LIKE '%${query}%'`;
  
  connection.query(sql, function(err, results, fields) {
    if (err){
      console.log(err);
    } 
    console.log(results);
    res.render('salarySearch', {data: results});
  });
});

module.exports = router;
