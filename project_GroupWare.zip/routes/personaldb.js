const express = require('express');
const router = express.Router();
const connection = require('../db');

/*router.get('/', function(req, res){
  res.render('personal')
});
*/
router.get('/', function(req, res) {
  const query = req.query.query;
  
  const sql = `SELECT personal.name, personal.phone_num, salary.rank_name, salary.salary FROM personal JOIN salary ON personal.rank_num = salary.id WHERE personal.name LIKE '${query}';`
  
  connection.query(sql, function(err, results, fields) {
    if (err){
      console.log(err);
    }
    console.log(results);
    res.render('personalSearch', {data: results});
  });
});

module.exports = router;
