//var express = require('express');
//var router = express.Router();
//
//var inventory = require("./inventory");
//var personal = require("./personal");
//var salary = require("./salary");
//
//router.get('/inventory', function(req,res){
//    res.render('inventory');
//});
//router.get('/personal', function(req,res){
//    res.render('personal');
//});
//router.get('/salary', function(req,res){
//    res.render('salary');
//});

//module.exports = router;