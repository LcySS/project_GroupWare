var mysql = require("mysql2");
var db = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "lego",
  database: "mydb",
  dateStrings: "date",
});

module.exports = db;
